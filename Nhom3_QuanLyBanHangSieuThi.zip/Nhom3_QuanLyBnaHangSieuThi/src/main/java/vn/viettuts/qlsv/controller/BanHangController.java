/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vn.viettuts.qlsv.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import vn.viettuts.qlsv.dao.HangHoaDao;
import vn.viettuts.qlsv.dao.HoaDonDao;
import vn.viettuts.qlsv.dao.QuanLyHoaDonDao;
import vn.viettuts.qlsv.entity.HangHoa;
import vn.viettuts.qlsv.entity.HoaDon;
import vn.viettuts.qlsv.entity.QuanLyHoaDon;
import vn.viettuts.qlsv.view.BanHangView;
import vn.viettuts.qlsv.view.HangHoaInfoView;

/**
 *
 * @author JC
 */
public class BanHangController {

    private HoaDonDao hoaDonDao;
    private BanHangView banHangView;
    private HangHoaDao hangHoaDao;
    private QuanLyHoaDonDao qlHoaDonDao;

    private SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

    public BanHangController(BanHangView view) {
        this.banHangView = view;
        hangHoaDao = new HangHoaDao();
        hoaDonDao = new HoaDonDao();
        qlHoaDonDao = new QuanLyHoaDonDao();

        view.addThemVaoDonHangListener(new ThemVaoDonHangListener());
        view.addXoaKhoiDonHangListener(new XoaKhoiDonHangListener());
        view.addLuuHoaDonListener(new LuuHoaDonListener());

    }

    public void showBanHangView() {
        hangHoaDao.sortHangHoatByMaHangHoa();
        hoaDonDao.sortHoaDontByMaHangHoa();
        List<HoaDon> hoaDonList = hoaDonDao.getListHoaDon();
        List<HangHoa> hangHoaList = hangHoaDao.getListHangHoa();

        banHangView.setVisible(true);
        banHangView.showListHangHoa(hangHoaList);
        banHangView.showListHoaDon(hoaDonList);
    }

    class ThemVaoDonHangListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            double tongTien = banHangView.getTextTongTienLabel();
            HoaDon hoaDon = banHangView.getHoaDonInfo();
            hoaDonDao.add(hoaDon);
            banHangView.showListHoaDon(hoaDonDao.getListHoaDon());

            List<HoaDon> listHoaDon = hoaDonDao.getListHoaDon();
            for (HoaDon hoadon : listHoaDon) {
                tongTien += (hoaDon.getGiaBan() * hoaDon.getSoLuongMua());
            }
            banHangView.setTextTongTienLabel(tongTien + "");

            banHangView.showMessage("Thêm thành công!");
        }
    }

    class XoaKhoiDonHangListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            JTable hoaDonTable = banHangView.getHoaDonTable();
            int row = banHangView.getHoaDonFromSelectedRow();
            double tongTien = banHangView.getTextTongTienLabel();

            HoaDon hoaDon = searchHangHoaByMaHangInHoaDon(Integer.parseInt(hoaDonTable.getModel().getValueAt(row, 0).toString()));
            hoaDonDao.delete(hoaDon);
            banHangView.showListHoaDon(hoaDonDao.getListHoaDon());

            banHangView.setTexDonViTinhField();
            banHangView.setTextGiaBanField();
            banHangView.setTextMaHangField();
            banHangView.setTextTenHanfField();
            banHangView.setTextSoLuongField();

            List<HoaDon> listHoaDon = hoaDonDao.getListHoaDon();
            for (HoaDon hoadon : listHoaDon) {
                tongTien += (hoaDon.getGiaBan() * hoaDon.getSoLuongMua());
            }
            banHangView.setTextTongTienLabel(tongTien + "");
            banHangView.showMessage("Xóa thành công!");
        }
    }

    public HoaDon searchHangHoaByMaHangInHoaDon(int maHangHoa) {
        List<HoaDon> hangHoaList = hoaDonDao.getListHoaDon();
        try {
            for (HoaDon hangHoa : hangHoaList) {
                if (maHangHoa == hangHoa.getMaHang()) {
                    return hangHoa;
                }
            }
            throw new IllegalArgumentException("không tìm thấy mã hàng hóa.");
        } catch (IllegalArgumentException e) {
            banHangView.showMessage("Không tìm thấy hàng hóa có mã: " + maHangHoa);
        }
        return null;
    }

    class LuuHoaDonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            QuanLyHoaDon qlhd = new QuanLyHoaDon();
            qlhd.setMaHoaDon(banHangView.getMaHoaDonFromField());
            qlhd.setTenKhachHang(banHangView.getTenKhachHangFromField());
            qlhd.setTongTien(banHangView.getTextTongTienLabel());
            qlhd.setDateTaoHoaDon(banHangView.getDateTaoHoaDonFromField());

            qlHoaDonDao.add(qlhd);

            banHangView.setTextMaHoaDonField();
            banHangView.setTextTenKhacHangFieldField();
            banHangView.setDateLuuHoaDonField();
            banHangView.setTextTongTienLabel("");
        }
    }

}
