/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vn.viettuts.qlsv.dao;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import vn.viettuts.qlsv.entity.QuanLyHoaDon;
import vn.viettuts.qlsv.entity.QuanLyHoaDonXML;
import vn.viettuts.qlsv.utils.FileUtils;

/**
 *
 * @author miin
 */
public class QuanLyHoaDonDao {
    private static final String HOADON_FILE_NAME = "/config/doanVien.xml";
    private List<QuanLyHoaDon> listHoaDon;  
    
    public QuanLyHoaDonDao() {
        this.listHoaDon = readListHoaDon();
        if(listHoaDon == null) {
            listHoaDon = new ArrayList<QuanLyHoaDon>();
        }
    }
    
    public void writeListHoaDon(List<QuanLyHoaDon> listHoaDon) {
        QuanLyHoaDonXML hoaDonXML = new QuanLyHoaDonXML();
        hoaDonXML.setListHoaDon(listHoaDon);
        FileUtils.writeXMLtoFile(HOADON_FILE_NAME, hoaDonXML);
    }
    
    public List<QuanLyHoaDon> readListHoaDon() {
        List<QuanLyHoaDon> list = new ArrayList<QuanLyHoaDon>();
        try (InputStream inputStream = getClass().getResourceAsStream("/config/student.xml")) {
            if (inputStream != null) {
                QuanLyHoaDonXML studentXML = (QuanLyHoaDonXML) FileUtils.readXMLFromInputStream(inputStream, QuanLyHoaDonXML.class);
                if (studentXML != null) {
                    list = studentXML.getListHoaDon();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }  
    
    public void add(QuanLyHoaDon hoaDon) {
        listHoaDon.add(hoaDon);
        writeListHoaDon(listHoaDon);
    }
    
    public void edit(QuanLyHoaDon hoaDon) {
        int size = listHoaDon.size();
        for (int i = 0; i < size; i++) {
            if (listHoaDon.get(i).getMaHoaDon()== hoaDon.getMaHoaDon()) {                
                listHoaDon.get(i).setTenKhachHang(hoaDon.getTenKhachHang());
                listHoaDon.get(i).setTongTien(hoaDon.getTongTien());
                listHoaDon.get(i).setDateTaoHoaDon(hoaDon.getDateTaoHoaDon());
                writeListHoaDon(listHoaDon);
                break;
            }
        }
    }
    
    public void delete(QuanLyHoaDon hangHoa) {
        boolean isFound = false;
        int size = listHoaDon.size();
        for (int i = 0; i < size; i++) {
            if (listHoaDon.get(i).getMaHoaDon()== hangHoa.getMaHoaDon()) {
                hangHoa = listHoaDon.get(i);
                isFound = true;
                break;
            }
        }
        if (isFound) {      
            for (int k=hangHoa.getMaHoaDon(); k<size; k++){
                listHoaDon.get(k).setMaHoaDon(k);
            }
            listHoaDon.remove(hangHoa);
            writeListHoaDon(listHoaDon);
        }
    }
    
    public void sortHoaDontByMaHoaDon() {
        Collections.sort(listHoaDon, new Comparator<QuanLyHoaDon>() {
            @Override
            public int compare(QuanLyHoaDon hangHoa1, QuanLyHoaDon hangHoa2) {
                if (hangHoa1.getMaHoaDon() > hangHoa1.getMaHoaDon()) {
                    return 1;
                }
                return -1;
            }
        });
    }
    
    public List<QuanLyHoaDon> getListHoaDon() {
        return listHoaDon;
    }
    
    public void setListHoaDon(List<QuanLyHoaDon> listHoaDon) {
        this.listHoaDon = listHoaDon;
    }
    
    
}
