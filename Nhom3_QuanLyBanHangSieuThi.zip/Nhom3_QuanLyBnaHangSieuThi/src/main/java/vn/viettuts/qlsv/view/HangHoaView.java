/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vn.viettuts.qlsv.view;

import com.sun.org.apache.xerces.internal.impl.io.ASCIIReader;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import vn.viettuts.qlsv.controller.BanHangController;
import vn.viettuts.qlsv.controller.LoginController;
import vn.viettuts.qlsv.controller.HangHoaController;
import vn.viettuts.qlsv.entity.HangHoa;
import vn.viettuts.qlsv.view.edittable.TableCustom;

/**
 *
 * @author miin
 */
public class HangHoaView extends javax.swing.JFrame implements ActionListener, ListSelectionListener {

    private HomeView homeView;
    private LoginView loginView;
    private BanHangView banHangView;
    private ThongKeHoaDonView thongKeHoaDonView;
    private FilterView filterView;

    DefaultTableModel model;
    private boolean ASCSelected;
    private boolean DESCSelected;
    // định nghĩa các cột của bảng student
    private String[] studentColumnNames = new String[]{
        "Mã hàng", "Tên hàng", "Số lượng tồn", "Đơn vị tính", "Đơn giá", "Ngày nhập", "Giá bán"};

    // định nghĩa dữ liệu mặc định của bẳng student là rỗng
    private Object data = new Object[][]{};

    /**
     * Creates new form StudentViewReplace
     */
    public HangHoaView() {
        initComponents();
        customizeComponents();
        loadImage();
    }

    private void loadImage() {
        try {
            // Sử dụng getResourceAsStream để tải ảnh từ resources
            InputStream logoStream = getClass().getResourceAsStream("/images/logo.jpg");
            
            BufferedImage originalImage1 = ImageIO.read(logoStream);
            
            // Đóng các stream sau khi sử dụng
            if (logoStream != null) logoStream.close();


            // Kích thước mong muốn cho JLabel
            int labelWidth1 = a.getWidth();
            int labelHeight1 = a.getHeight();

            // Điều chỉnh kích thước ảnh
            Image scaledImage1 = originalImage1.getScaledInstance(labelWidth1, labelHeight1, Image.SCALE_SMOOTH);

            // Đặt ảnh đã chỉnh kích thước vào JLabel
            a.setIcon(new ImageIcon(scaledImage1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void customizeComponents() {
        //setExtendedState(JFrame.MAXIMIZED_BOTH);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        deleteHangHoaBtn.setEnabled(false);
        HangHoaInfoBtn.setEnabled(false);
        addHoangHoaBtn.setEnabled(true);
        model = (DefaultTableModel) hangHoaTable.getModel();

        // cài đặt các cột và data cho bảng student
        hangHoaTable.setModel(new DefaultTableModel((Object[][]) data, studentColumnNames));
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showListHangHoa(List<HangHoa> list) {
        DecimalFormat formatter = new DecimalFormat("#,###");
        int size = list.size();
        // với bảng studentTable có 15 cột, 
        // khởi tạo mảng 2 chiều students, trong đó:
        // số hàng: là kích thước của list student 
        // số cột: là 15
        Object[][] students = new Object[size][7];
        for (int i = 0; i < size; i++) {
            students[i][0] = list.get(i).getMaHangHoa();
            students[i][1] = list.get(i).getTenHangHoa();
            students[i][2] = list.get(i).getSoLuong();
            students[i][3] = list.get(i).getDonViTinh();
            students[i][4] = list.get(i).getDonGia();
            students[i][5] = list.get(i).getDateNhapHang();
            students[i][6] = list.get(i).getGiaBan();

        }
        // Edit table
        hangHoaTable.setModel(new DefaultTableModel(students, studentColumnNames));
        TableColumnModel colStudentModel = hangHoaTable.getColumnModel();
        colStudentModel.getColumn(0).setPreferredWidth(32);
        colStudentModel.getColumn(1).setPreferredWidth(125);
        colStudentModel.getColumn(2).setPreferredWidth(38);
        colStudentModel.getColumn(3).setPreferredWidth(45);
        colStudentModel.getColumn(4).setPreferredWidth(55);
        colStudentModel.getColumn(5).setPreferredWidth(40);
        colStudentModel.getColumn(6).setPreferredWidth(200);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logoutPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        hangHoaTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        addHoangHoaBtn = new javax.swing.JButton();
        deleteHangHoaBtn = new javax.swing.JButton();
        showAllHangHoa = new javax.swing.JButton();
        HangHoaInfoBtn = new javax.swing.JButton();
        filterBtn = new javax.swing.JButton();
        chucNangPanel = new javax.swing.JPanel();
        searchLabel = new javax.swing.JLabel();
        sortLabel = new javax.swing.JLabel();
        searchByTenHangBtn = new javax.swing.JButton();
        searchByDonViTinhBtn = new javax.swing.JButton();
        SearchByMaHangBtn = new javax.swing.JButton();
        sortByMaHangBtn = new javax.swing.JButton();
        sortByTenHangBtn = new javax.swing.JButton();
        sortByDonGiaBtn = new javax.swing.JButton();
        ASC = new javax.swing.JRadioButton();
        DESC = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        sortByGiaBanBtn = new javax.swing.JButton();
        sortBySoLuongBtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        banHangPanel = new javax.swing.JPanel();
        doanvienLabel = new javax.swing.JLabel();
        thongKeHoaDonPanel = new javax.swing.JPanel();
        dangvienLabel = new javax.swing.JLabel();
        thongkePanel = new javax.swing.JPanel();
        logoutPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        hangHoaPanel = new javax.swing.JPanel();
        sinhvienLabel = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        logoLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        logoPanel = new javax.swing.JPanel();
        a = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản lý bán hàng siêu thị");

        logoutPanel.setBackground(new java.awt.Color(255, 255, 255));

        hangHoaTable.setBackground(new java.awt.Color(255, 255, 224));
        hangHoaTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        hangHoaTable.setToolTipText("");
        jScrollPane1.setViewportView(hangHoaTable);

        addHoangHoaBtn.setText("Thêm");
        addHoangHoaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addHoangHoaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addHoangHoaBtnActionPerformed(evt);
            }
        });

        deleteHangHoaBtn.setText("Xóa");
        deleteHangHoaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        showAllHangHoa.setText("Hiển thị tất cả hàng hóa");
        showAllHangHoa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        HangHoaInfoBtn.setText("Sửa thông tin hàng hóa");
        HangHoaInfoBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        filterBtn.setText("Filter");
        filterBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        filterBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(addHoangHoaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteHangHoaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(filterBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(HangHoaInfoBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(showAllHangHoa, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(219, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(filterBtn)
                    .addComponent(addHoangHoaBtn)
                    .addComponent(deleteHangHoaBtn))
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(HangHoaInfoBtn)
                    .addComponent(showAllHangHoa))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        chucNangPanel.setToolTipText("");

        searchLabel.setText("Search by");

        sortLabel.setText("Sort by");

        searchByTenHangBtn.setText("Tên hàng");
        searchByTenHangBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        searchByDonViTinhBtn.setText("Đơn vị tính");
        searchByDonViTinhBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        SearchByMaHangBtn.setText("Mã hàng");
        SearchByMaHangBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        sortByMaHangBtn.setText("Mã hàng");
        sortByMaHangBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortByMaHangBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortByMaHangBtnActionPerformed(evt);
            }
        });

        sortByTenHangBtn.setText("Tên hàng");
        sortByTenHangBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        sortByDonGiaBtn.setText("Đơn giá");
        sortByDonGiaBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortByDonGiaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortByDonGiaBtnActionPerformed(evt);
            }
        });

        ASC.setText("ASC");
        ASC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ASC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ASCActionPerformed(evt);
            }
        });

        DESC.setText("DESC");
        DESC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DESC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DESCActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Chức năng");

        sortByGiaBanBtn.setText("Giá bán");
        sortByGiaBanBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortByGiaBanBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortByGiaBanBtnActionPerformed(evt);
            }
        });

        sortBySoLuongBtn.setText("Số lượng");
        sortBySoLuongBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortBySoLuongBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortBySoLuongBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout chucNangPanelLayout = new javax.swing.GroupLayout(chucNangPanel);
        chucNangPanel.setLayout(chucNangPanelLayout);
        chucNangPanelLayout.setHorizontalGroup(
            chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(chucNangPanelLayout.createSequentialGroup()
                        .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(searchLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sortLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(chucNangPanelLayout.createSequentialGroup()
                                .addComponent(SearchByMaHangBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchByTenHangBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchByDonViTinhBtn))
                            .addGroup(chucNangPanelLayout.createSequentialGroup()
                                .addComponent(sortByMaHangBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sortByTenHangBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sortByDonGiaBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sortByGiaBanBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sortBySoLuongBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ASC)
                                .addGap(18, 18, 18)
                                .addComponent(DESC))))
                    .addComponent(jLabel1))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        chucNangPanelLayout.setVerticalGroup(
            chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chucNangPanelLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLabel)
                    .addComponent(SearchByMaHangBtn)
                    .addComponent(searchByTenHangBtn)
                    .addComponent(searchByDonViTinhBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(chucNangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sortLabel)
                    .addComponent(sortByMaHangBtn)
                    .addComponent(sortByTenHangBtn)
                    .addComponent(sortByDonGiaBtn)
                    .addComponent(ASC)
                    .addComponent(DESC)
                    .addComponent(sortByGiaBanBtn)
                    .addComponent(sortBySoLuongBtn))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(chucNangPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chucNangPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 204, 204));

        homePanel.setBackground(new java.awt.Color(0, 204, 204));
        homePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homePanelMouseClicked(evt);
            }
        });

        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        homeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        homeLabel.setText("Home");
        homeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        homeLabel.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                homeLabelAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        banHangPanel.setBackground(new java.awt.Color(0, 204, 204));
        banHangPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                banHangPanelMouseClicked(evt);
            }
        });

        doanvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        doanvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        doanvienLabel.setText("Bán hàng");
        doanvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout banHangPanelLayout = new javax.swing.GroupLayout(banHangPanel);
        banHangPanel.setLayout(banHangPanelLayout);
        banHangPanelLayout.setHorizontalGroup(
            banHangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        banHangPanelLayout.setVerticalGroup(
            banHangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongKeHoaDonPanel.setBackground(new java.awt.Color(0, 204, 204));
        thongKeHoaDonPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongKeHoaDonPanelMouseClicked(evt);
            }
        });

        dangvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dangvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dangvienLabel.setText("Thống kê hóa đơn");
        dangvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout thongKeHoaDonPanelLayout = new javax.swing.GroupLayout(thongKeHoaDonPanel);
        thongKeHoaDonPanel.setLayout(thongKeHoaDonPanelLayout);
        thongKeHoaDonPanelLayout.setHorizontalGroup(
            thongKeHoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
        );
        thongKeHoaDonPanelLayout.setVerticalGroup(
            thongKeHoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongkePanel.setBackground(new java.awt.Color(0, 204, 204));
        thongkePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongkePanelMouseClicked(evt);
            }
        });

        logoutPanel1.setBackground(new java.awt.Color(0, 204, 204));
        logoutPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Đăng xuất\n");

        javax.swing.GroupLayout logoutPanel1Layout = new javax.swing.GroupLayout(logoutPanel1);
        logoutPanel1.setLayout(logoutPanel1Layout);
        logoutPanel1Layout.setHorizontalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoutPanel1Layout.setVerticalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logoutPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout thongkePanelLayout = new javax.swing.GroupLayout(thongkePanel);
        thongkePanel.setLayout(thongkePanelLayout);
        thongkePanelLayout.setHorizontalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongkePanelLayout.setVerticalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        hangHoaPanel.setBackground(new java.awt.Color(0, 204, 204));
        hangHoaPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hangHoaPanelMouseClicked(evt);
            }
        });

        sinhvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        sinhvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sinhvienLabel.setText("Hàng hóa");
        sinhvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout hangHoaPanelLayout = new javax.swing.GroupLayout(hangHoaPanel);
        hangHoaPanel.setLayout(hangHoaPanelLayout);
        hangHoaPanelLayout.setHorizontalGroup(
            hangHoaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        hangHoaPanelLayout.setVerticalGroup(
            hangHoaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sinhvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashboardLabel.setText("Welcome !");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(hangHoaPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(banHangPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongKeHoaDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongkePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dashboardLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(homePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hangHoaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(banHangPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongKeHoaDonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongkePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Hệ thống quản lý bán hàng siêu thị");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1226, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout logoPanelLayout = new javax.swing.GroupLayout(logoPanel);
        logoPanel.setLayout(logoPanelLayout);
        logoPanelLayout.setHorizontalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(a, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        logoPanelLayout.setVerticalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(a, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout logoutPanelLayout = new javax.swing.GroupLayout(logoutPanel);
        logoutPanel.setLayout(logoutPanelLayout);
        logoutPanelLayout.setHorizontalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        logoutPanelLayout.setVerticalGroup(
            logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logoutPanelLayout.createSequentialGroup()
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(logoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logoutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logoutPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addHoangHoaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addHoangHoaBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addHoangHoaBtnActionPerformed

    private void ASCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ASCActionPerformed
        // TODO add your handling code here:
        if (ASC.isSelected()) {
            ASCSelected = true;
            DESCSelected = false;
            DESC.setSelected(false);
        } else {
            ASCSelected = false;
        }
    }//GEN-LAST:event_ASCActionPerformed

    private void sortByDonGiaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortByDonGiaBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortByDonGiaBtnActionPerformed

    private void DESCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DESCActionPerformed
        // TODO add your handling code here:
        if (DESC.isSelected()) {
            DESCSelected = true;
            ASCSelected = false;
            ASC.setSelected(false);
        } else {
            DESCSelected = false;
        }
    }//GEN-LAST:event_DESCActionPerformed

    private void homePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homePanelMouseClicked
        homeView = new HomeView();

        homeView.setVisible(true);
        this.setVisible(false);

        homePanel.setBackground(new Color(255, 255, 255));
        hangHoaPanel.setBackground(new Color(0, 204, 204));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongKeHoaDonPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_homePanelMouseClicked

    private void banHangPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_banHangPanelMouseClicked
        banHangView = new BanHangView();

        BanHangController banHangController = new BanHangController(banHangView);
        this.setVisible(false);
        banHangView.setVisible(true);
        banHangController.showBanHangView();

        homePanel.setBackground(new Color(0, 204, 204));
        hangHoaPanel.setBackground(new Color(255, 255, 255));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongKeHoaDonPanel.setBackground(new Color(0, 204, 204));

    }//GEN-LAST:event_banHangPanelMouseClicked

    private void thongKeHoaDonPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongKeHoaDonPanelMouseClicked
        thongKeHoaDonView = new ThongKeHoaDonView();

        this.setVisible(false);
        thongKeHoaDonView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        hangHoaPanel.setBackground(new Color(255, 255, 255));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongKeHoaDonPanel.setBackground(new Color(0, 204, 204));

    }//GEN-LAST:event_thongKeHoaDonPanelMouseClicked

    private void thongkePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongkePanelMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_thongkePanelMouseClicked

    private void hangHoaPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hangHoaPanelMouseClicked
        // TODO add your handling code here:
//        filterView = new FilterView();
//        HangHoaController studentController = new HangHoaController(studentView, filterView);
//        studentController.showStudentView();
//        studentView.setLocationRelativeTo(loginView);
//
//        homeView.setVisible(false);
//        studentView.setVisible(true);
//        doanvienView.setVisible(false);
//        dangvienView.setVisible(false);
//        thongkeView.setVisible(false);
//
//        homePanel.setBackground(new Color(0, 204, 204));
//        sinhvienPanel.setBackground(new Color(255, 255, 255));
//        doanvienPanel.setBackground(new Color(0, 204, 204));
//        dangvienPanel.setBackground(new Color(0, 204, 204));
//        thongkePanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_hangHoaPanelMouseClicked

    private void logoutPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanel1MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_logoutPanel1MouseClicked

    private void sortByMaHangBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortByMaHangBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortByMaHangBtnActionPerformed

    private void sortByGiaBanBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortByGiaBanBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortByGiaBanBtnActionPerformed

    private void sortBySoLuongBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortBySoLuongBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortBySoLuongBtnActionPerformed

    private void filterBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filterBtnActionPerformed

    private void homeLabelAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_homeLabelAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_homeLabelAncestorAdded

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HangHoaView().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ASC;
    private javax.swing.JRadioButton DESC;
    private javax.swing.JButton HangHoaInfoBtn;
    private javax.swing.JButton SearchByMaHangBtn;
    private javax.swing.JLabel a;
    private javax.swing.JButton addHoangHoaBtn;
    private javax.swing.JPanel banHangPanel;
    private javax.swing.JPanel chucNangPanel;
    private javax.swing.JLabel dangvienLabel;
    private javax.swing.JLabel dashboardLabel;
    private javax.swing.JButton deleteHangHoaBtn;
    private javax.swing.JLabel doanvienLabel;
    private javax.swing.JButton filterBtn;
    private javax.swing.JPanel hangHoaPanel;
    private javax.swing.JTable hangHoaTable;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel logoutPanel;
    private javax.swing.JPanel logoutPanel1;
    private javax.swing.JButton searchByDonViTinhBtn;
    private javax.swing.JButton searchByTenHangBtn;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JButton showAllHangHoa;
    private javax.swing.JLabel sinhvienLabel;
    private javax.swing.JButton sortByDonGiaBtn;
    private javax.swing.JButton sortByGiaBanBtn;
    private javax.swing.JButton sortByMaHangBtn;
    private javax.swing.JButton sortBySoLuongBtn;
    private javax.swing.JButton sortByTenHangBtn;
    private javax.swing.JLabel sortLabel;
    private javax.swing.JPanel thongKeHoaDonPanel;
    private javax.swing.JPanel thongkePanel;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * Lấy danh sách thông tin student từ Table
     *
     * @return
     */
    public List<Integer> getListMahangHoaTable() {
        List<Integer> listMaHangHoa = new ArrayList<>();
        TableModel tableModel = hangHoaTable.getModel();
        int rowCount = tableModel.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            int maHangHoa = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
            listMaHangHoa.add(maHangHoa);
        }
        return listMaHangHoa;
    }

    public JTable getHangHoaTable() {
        return this.hangHoaTable;
    }

    public int getHangHoaFromSelectedRow() {
        return hangHoaTable.getSelectedRow();
    }

    public void setEnableSuaThongTinHangHoa(boolean isEnable) {
        this.HangHoaInfoBtn.setEnabled(isEnable);
    }

    public void setEnableDleteHangHoaBtn(boolean isEnable) {
        deleteHangHoaBtn.setEnabled(isEnable);
    }

    public boolean enableASCBtn() {
        return ASCSelected;
    }

    public boolean enableDESCBtn() {
        return DESCSelected;
    }

    public void addAddHangHoaListener(ActionListener listener) {
        addHoangHoaBtn.addActionListener(listener);
    }

    public void addFilterHangHoaListener(ActionListener listener) {
        filterBtn.addActionListener(listener);
    }

    public void addDeleteHangHoaListener(ActionListener listener) {
        deleteHangHoaBtn.addActionListener(listener);
    }

    public void addSortByMaHangListener(ActionListener listener) {
        sortByMaHangBtn.addActionListener(listener);
    }

    public void addSortByDonGiaListener(ActionListener listener) {
        sortByDonGiaBtn.addActionListener(listener);
    }

    public void addSortByTenHangListener(ActionListener listener) {
        sortByTenHangBtn.addActionListener(listener);
    }

    public void addSortByGiaBanListener(ActionListener listener) {
        sortByGiaBanBtn.addActionListener(listener);
    }

    public void addSortBySoLuongListener(ActionListener listener) {
        sortBySoLuongBtn.addActionListener(listener);
    }

    public void addHangHoaInfoListener(ActionListener listener) {
        HangHoaInfoBtn.addActionListener(listener);
    }

    public void addShowAllHangHoaListener(ActionListener listener) {
        showAllHangHoa.addActionListener(listener);
    }

    public void addSearchByMaHangListener(ActionListener listener) {
        SearchByMaHangBtn.addActionListener(listener);
    }

    public void addSearchByTenHangListener(ActionListener listener) {
        searchByTenHangBtn.addActionListener(listener);
    }

    public void addSearchByDonViTinhListener(ActionListener listener) {
        searchByDonViTinhBtn.addActionListener(listener);
    }

    public void addListHangHoaSelectionListener(ListSelectionListener listener) {
        hangHoaTable.getSelectionModel().addListSelectionListener(listener);
    }

}
