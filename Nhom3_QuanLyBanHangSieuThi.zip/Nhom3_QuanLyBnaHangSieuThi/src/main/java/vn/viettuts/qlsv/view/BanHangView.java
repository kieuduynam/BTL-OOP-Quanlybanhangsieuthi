/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vn.viettuts.qlsv.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import vn.viettuts.qlsv.controller.HangHoaController;
import vn.viettuts.qlsv.dao.HangHoaDao;
import vn.viettuts.qlsv.dao.HoaDonDao;
import vn.viettuts.qlsv.dao.QuanLyHoaDonDao;
import vn.viettuts.qlsv.entity.HangHoa;
import vn.viettuts.qlsv.entity.HoaDon;
import vn.viettuts.qlsv.entity.QuanLyHoaDon;

/**
 *
 * @author miin
 */
public class BanHangView extends javax.swing.JFrame implements ActionListener, ListSelectionListener {

    private SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

    private HomeView homeView;
    private HangHoaView hangHoaView;
    private LoginView loginView;
    private FilterView filterView;
    private ThongKeHoaDonView thongKeHoaDonView;
    private QuanLyHoaDonDao quanLyHoaDonDao;
    private HangHoaDao hangHoaDao;
    private HoaDonDao hoaDonDao;

    private void loadImage() {
        try {
            // Sử dụng getResourceAsStream để tải ảnh từ resources
            InputStream logoStream = getClass().getResourceAsStream("/images/logo.jpg");
            
            BufferedImage originalImage1 = ImageIO.read(logoStream);
            
            // Đóng các stream sau khi sử dụng
            if (logoStream != null) logoStream.close();


            // Kích thước mong muốn cho JLabel
            int labelWidth1 = logoLabel.getWidth();
            int labelHeight1 = logoLabel.getHeight();

            // Điều chỉnh kích thước ảnh
            Image scaledImage1 = originalImage1.getScaledInstance(labelWidth1, labelHeight1, Image.SCALE_SMOOTH);

            // Đặt ảnh đã chỉnh kích thước vào JLabel
            logoLabel.setIcon(new ImageIcon(scaledImage1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    NumberFormat formatter = NumberFormat.getInstance(new Locale("vi", "VN"));
    DefaultTableModel hangHoamodel;
    DefaultTableModel hoaDonmodel;

    private final String[] hangHoaColumnName = new String[]{
        "Mã hàng", "Tên hàng", "Số lượng tồn", "Đơn vị tính", "Giá bán"};

    private final String[] hoaDonColumnName = new String[]{
        "Mã hàng", "Tên hàng", "Số Lượng mua", "Đơn vị tính", "Giá bán"};

    private final Object data1 = new Object[][]{};
    private final Object data2 = new Object[][]{};

    /**
     * Creates new form DoanVienView
     */
    public BanHangView() {
        initComponents();
        customizeComponents();
        loadImage();
    }

    private void customizeComponents() {
        //setExtendedState(JFrame.MAXIMIZED_BOTH);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        themVaoDonHangBtn.setEnabled(true);
        xoaKhoiDonHangBtn.setEnabled(true);
        luuHoaDonBtn.setEnabled(true);
        hangHoamodel = (DefaultTableModel) hangHoaTable.getModel();
        hoaDonmodel = (DefaultTableModel) hoaDonTable.getModel();

        // cài đặt các cột và data cho bảng student
        hangHoaTable.setModel(new DefaultTableModel((Object[][]) data1, hangHoaColumnName));
        hoaDonTable.setModel(new DefaultTableModel((Object[][]) data2, hoaDonColumnName));

    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void showListHangHoa(List<HangHoa> list) {
        int size = list.size();

        Object[][] students = new Object[size][5];
        for (int i = 0; i < size; i++) {
            students[i][0] = list.get(i).getMaHangHoa();
            students[i][1] = list.get(i).getTenHangHoa();
            students[i][2] = list.get(i).getSoLuong();
            students[i][3] = list.get(i).getDonViTinh();
            students[i][4] = list.get(i).getGiaBan();
        }

        hangHoaTable.setModel(new DefaultTableModel(students, hangHoaColumnName));
        TableColumnModel colStudentModel = hangHoaTable.getColumnModel();
        colStudentModel.getColumn(0).setPreferredWidth(32);
        colStudentModel.getColumn(1).setPreferredWidth(125);
        colStudentModel.getColumn(2).setPreferredWidth(38);
        colStudentModel.getColumn(3).setPreferredWidth(45);
        colStudentModel.getColumn(4).setPreferredWidth(55);
    }

    public void showListHoaDon(List<HoaDon> list) {
        int size = list.size();

        Object[][] students = new Object[size][5];
        for (int i = 0; i < size; i++) {
            students[i][0] = list.get(i).getMaHang();
            students[i][1] = list.get(i).getTenHangHoa();
            students[i][2] = list.get(i).getSoLuongMua();
            students[i][3] = list.get(i).getDonViTinh();
            students[i][4] = list.get(i).getGiaBan();
        }

        hoaDonTable.setModel(new DefaultTableModel(students, hoaDonColumnName));
        TableColumnModel colStudentModel = hangHoaTable.getColumnModel();
        colStudentModel.getColumn(0).setPreferredWidth(32);
        colStudentModel.getColumn(1).setPreferredWidth(125);
        colStudentModel.getColumn(2).setPreferredWidth(38);
        colStudentModel.getColumn(3).setPreferredWidth(45);
        colStudentModel.getColumn(4).setPreferredWidth(55);
    }

    public HoaDon getHoaDonInfo() {
        if (!ValidateSoLuongMua()) {
            return null;
        }
        try {
            HoaDon hoaDon = new HoaDon();

            if (maHangField.getText() != null && !"".equals(maHangField.getText())) {
                hoaDon.setMaHang(Integer.parseInt(maHangField.getText()));
            }
            hoaDon.setTenHangHoa(tenHangField.getText().trim());
            hoaDon.setTenHangHoa(tenHangField.getText().trim());
            hoaDon.setSoLuongMua(Integer.parseInt(soLuongField.getText().trim()));
            hoaDon.setGiaBan(Double.parseDouble(giaBanField.getText().trim()));
            return hoaDon;
        } catch (Exception e) {
            showMessage(e.getMessage());
        }

        return null;

    }

    public QuanLyHoaDon getQuanLyHoaDoInfo() {
        if (!validateDateLuuHoaDon()) {
            return null;
        }
        try {
            QuanLyHoaDon qlhd = new QuanLyHoaDon();

            if (maHangField.getText() != null && !"".equals(maHangField.getText())) {
                qlhd.setMaHoaDon(Integer.parseInt(maHoaDonField.getText()));
            }
            qlhd.setTenKhachHang(tenKhachHangField.getText().trim());
            qlhd.setTongTien(Double.parseDouble(tongTienLable.getText().trim()));

            Date dateTao = dateTaoHoaDon.getDate();
            if (dateTao != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                String dateString = sdf.format(dateTao);
                qlhd.setDateTaoHoaDon(dateString);  // Lưu dưới dạng String
            }

            return qlhd;
        } catch (Exception e) {
            showMessage(e.getMessage());
        }

        return null;
    }

    private boolean ValidateSoLuongMua() {
        int maHang = Integer.parseInt(maHangField.getText());
        HangHoa hangHoa = searchHangHoaByMaHang(maHang);
        int soLuongMua = Integer.parseInt(soLuongField.getText());

        String address = soLuongField.getText();
        if (address == null || "".equals(address.trim())) {
            soLuongField.requestFocus();
            showMessage("Số lượng hàng hóa không được trống.");
            return false;
        }
        if (soLuongMua > hangHoa.getSoLuong()) {
            showMessage("Số lượng hàng muốn mua đã vượt quá số lượng hàng tồn.");
            return false;
        }
        return true;
    }

    private boolean validateDateLuuHoaDon() {
        Date date = dateTaoHoaDon.getDate();  // Lấy giá trị Date từ JDateChooser
        if (date == null) {  // Kiểm tra nếu ngày chưa được chọn
            dateTaoHoaDon.requestFocus();
            showMessage("Ngày tạo hóa đơn không được trống.");
            return false;
        }
        return true;
    }

    public HangHoa searchHangHoaByMaHang(int maHangHoa) {
        List<HangHoa> hangHoaList = hangHoaDao.getListHangHoa();
        try {
            for (HangHoa hangHoa : hangHoaList) {
                if (maHangHoa == hangHoa.getMaHangHoa()) {
                    return hangHoa;
                }
            }
            throw new IllegalArgumentException("không tìm thấy mã hàng hóa.");
        } catch (IllegalArgumentException e) {
            hangHoaView.showMessage("Không tìm thấy hàng hóa có mã: " + maHangHoa);
        }
        return null;
    }

    public int getMaHangFromField() {
        return Integer.parseInt(maHangField.getText());
    }

    public String getTenHangFromField() {
        return tenHangField.getText();
    }

    public int getSoLuongFromField() {
        return Integer.parseInt(soLuongField.getText());
    }

    public String getDonViTinhFromField() {
        return donViTinhField.getText();
    }

    public double getGiaBanFromField() {
        return Double.parseDouble(giaBanField.getText());
    }

    public int getMaHoaDonFromField() {
        return Integer.parseInt(maHoaDonField.getText());
    }

    public String getTenKhachHangFromField() {
        return tenKhachHangField.getText();
    }

    public String getDateTaoHoaDonFromField() {
        Date date = dateTaoHoaDon.getDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String dateString = sdf.format(date);
        return dateString;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        banHangPanel = new javax.swing.JPanel();
        doanvienLabel = new javax.swing.JLabel();
        thongKeHoaDonPanel = new javax.swing.JPanel();
        dangvienLabel = new javax.swing.JLabel();
        thongkePanel = new javax.swing.JPanel();
        logoutPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        hangHoaPanel = new javax.swing.JPanel();
        hangHoaLabel = new javax.swing.JLabel();
        dashboardLabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        logoPanel = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        maHoaDonField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tenKhachHangField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tongTienLable = new javax.swing.JLabel();
        luuHoaDonBtn = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        dateTaoHoaDon = new com.toedter.calendar.JDateChooser();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        hangHoaTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        maHangField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tenHangField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        soLuongField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        donViTinhField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        giaBanField = new javax.swing.JTextField();
        xoaKhoiDonHangBtn = new javax.swing.JButton();
        themVaoDonHangBtn = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        hoaDonTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 204, 204));

        homePanel.setBackground(new java.awt.Color(0, 204, 204));
        homePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homePanelMouseClicked(evt);
            }
        });

        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        homeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        homeLabel.setText("Home");
        homeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homePanelLayout.createSequentialGroup()
                .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        banHangPanel.setBackground(new java.awt.Color(0, 204, 204));
        banHangPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                banHangPanelMouseClicked(evt);
            }
        });

        doanvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        doanvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        doanvienLabel.setText("Bán hàng");
        doanvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout banHangPanelLayout = new javax.swing.GroupLayout(banHangPanel);
        banHangPanel.setLayout(banHangPanelLayout);
        banHangPanelLayout.setHorizontalGroup(
            banHangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        banHangPanelLayout.setVerticalGroup(
            banHangPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(doanvienLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongKeHoaDonPanel.setBackground(new java.awt.Color(0, 204, 204));
        thongKeHoaDonPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongKeHoaDonPanelMouseClicked(evt);
            }
        });

        dangvienLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        dangvienLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dangvienLabel.setText("Thống kê hóa đơn");
        dangvienLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout thongKeHoaDonPanelLayout = new javax.swing.GroupLayout(thongKeHoaDonPanel);
        thongKeHoaDonPanel.setLayout(thongKeHoaDonPanelLayout);
        thongKeHoaDonPanelLayout.setHorizontalGroup(
            thongKeHoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongKeHoaDonPanelLayout.setVerticalGroup(
            thongKeHoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dangvienLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        thongkePanel.setBackground(new java.awt.Color(0, 204, 204));
        thongkePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thongkePanelMouseClicked(evt);
            }
        });

        logoutPanel1.setBackground(new java.awt.Color(0, 204, 204));
        logoutPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutPanel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Đăng xuất\n");

        javax.swing.GroupLayout logoutPanel1Layout = new javax.swing.GroupLayout(logoutPanel1);
        logoutPanel1.setLayout(logoutPanel1Layout);
        logoutPanel1Layout.setHorizontalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logoutPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        logoutPanel1Layout.setVerticalGroup(
            logoutPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logoutPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout thongkePanelLayout = new javax.swing.GroupLayout(thongkePanel);
        thongkePanel.setLayout(thongkePanelLayout);
        thongkePanelLayout.setHorizontalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        thongkePanelLayout.setVerticalGroup(
            thongkePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        hangHoaPanel.setBackground(new java.awt.Color(0, 204, 204));
        hangHoaPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hangHoaPanelMouseClicked(evt);
            }
        });

        hangHoaLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        hangHoaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        hangHoaLabel.setText("Hàng hóa");
        hangHoaLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout hangHoaPanelLayout = new javax.swing.GroupLayout(hangHoaPanel);
        hangHoaPanel.setLayout(hangHoaPanelLayout);
        hangHoaPanelLayout.setHorizontalGroup(
            hangHoaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hangHoaPanelLayout.createSequentialGroup()
                .addComponent(hangHoaLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        hangHoaPanelLayout.setVerticalGroup(
            hangHoaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(hangHoaLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        dashboardLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        dashboardLabel.setForeground(new java.awt.Color(255, 255, 255));
        dashboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashboardLabel.setText("Welcome !");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(hangHoaPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(banHangPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongKeHoaDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(thongkePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(dashboardLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(dashboardLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(homePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hangHoaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(banHangPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thongKeHoaDonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(thongkePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Hệ thống quản lý bán hàng siêu thị");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1330, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout logoPanelLayout = new javax.swing.GroupLayout(logoPanel);
        logoPanel.setLayout(logoPanelLayout);
        logoPanelLayout.setHorizontalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
        );
        logoPanelLayout.setVerticalGroup(
            logoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, logoPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("Tên khác hàng");

        maHoaDonField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maHoaDonFieldActionPerformed(evt);
            }
        });

        jLabel9.setText("Mã hóa đơn");

        tenKhachHangField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tenKhachHangFieldActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 0));
        jLabel10.setText("Tổng tiền");

        tongTienLable.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        luuHoaDonBtn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        luuHoaDonBtn.setText("Lưu hóa đơn");
        luuHoaDonBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                luuHoaDonBtnActionPerformed(evt);
            }
        });

        jLabel12.setText("Ngày tạo hóa đơn");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setText("đ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(luuHoaDonBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tenKhachHangField, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel1)
                            .addComponent(jLabel12)
                            .addComponent(maHoaDonField))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(dateTaoHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tongTienLable, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(jLabel11)
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(maHoaDonField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tenKhachHangField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dateTaoHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(189, 189, 189)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tongTienLable, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(luuHoaDonBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        hangHoaTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        hangHoaTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hangHoaTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(hangHoaTable);

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setText("Mã hàng:");

        maHangField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maHangFieldActionPerformed(evt);
            }
        });

        jLabel5.setText("Tên hàng:");

        tenHangField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tenHangFieldActionPerformed(evt);
            }
        });

        jLabel6.setText("Số lượng:");

        soLuongField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                soLuongFieldActionPerformed(evt);
            }
        });

        jLabel7.setText("Đơn vị tính:");

        donViTinhField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                donViTinhFieldActionPerformed(evt);
            }
        });

        jLabel8.setText("Giá bán:");

        xoaKhoiDonHangBtn.setText("Xóa khỏi đơn hàng");
        xoaKhoiDonHangBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xoaKhoiDonHangBtnActionPerformed(evt);
            }
        });

        themVaoDonHangBtn.setText("Thêm vào đơn hàng");
        themVaoDonHangBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                themVaoDonHangBtnMouseClicked(evt);
            }
        });
        themVaoDonHangBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                themVaoDonHangBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(maHangField)
                        .addGap(18, 18, 18)
                        .addComponent(giaBanField, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(tenHangField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(88, 88, 88)
                                .addComponent(jLabel8))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(themVaoDonHangBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(soLuongField))
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(xoaKhoiDonHangBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(donViTinhField))))))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(2, 2, 2)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maHangField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(giaBanField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tenHangField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(donViTinhField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(soLuongField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(104, 104, 104))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(xoaKhoiDonHangBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(themVaoDonHangBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40))))
        );

        hoaDonTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        hoaDonTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hoaDonTableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(hoaDonTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 699, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(logoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homePanelMouseClicked
        filterView = new FilterView();

        homeView = new HomeView();

        this.setVisible(false);
        homeView.setVisible(true);

        homePanel.setBackground(new Color(255, 255, 255));
        hangHoaPanel.setBackground(new Color(0, 204, 204));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongKeHoaDonPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_homePanelMouseClicked

    private void banHangPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_banHangPanelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_banHangPanelMouseClicked

    private void thongKeHoaDonPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongKeHoaDonPanelMouseClicked
        thongKeHoaDonView = new ThongKeHoaDonView();

        this.setVisible(false);
        thongKeHoaDonView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        hangHoaPanel.setBackground(new Color(255, 255, 255));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongKeHoaDonPanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_thongKeHoaDonPanelMouseClicked

    private void logoutPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutPanel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_logoutPanel1MouseClicked

    private void thongkePanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_thongkePanelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_thongkePanelMouseClicked

    private void hangHoaPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hangHoaPanelMouseClicked
        hangHoaView = new HangHoaView();
        filterView = new FilterView();
        HangHoaController studentController = new HangHoaController(hangHoaView, filterView);
        studentController.showHangHoaView();
        hangHoaView.setLocationRelativeTo(loginView);

        this.setVisible(false);
        hangHoaView.setVisible(true);

        homePanel.setBackground(new Color(0, 204, 204));
        hangHoaPanel.setBackground(new Color(255, 255, 255));
        banHangPanel.setBackground(new Color(0, 204, 204));
        thongkePanel.setBackground(new Color(0, 204, 204));
    }//GEN-LAST:event_hangHoaPanelMouseClicked

    private void maHoaDonFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maHoaDonFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_maHoaDonFieldActionPerformed

    private void tenKhachHangFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tenKhachHangFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tenKhachHangFieldActionPerformed

    private void luuHoaDonBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_luuHoaDonBtnActionPerformed

    }//GEN-LAST:event_luuHoaDonBtnActionPerformed

    private void themVaoDonHangBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_themVaoDonHangBtnActionPerformed

    }//GEN-LAST:event_themVaoDonHangBtnActionPerformed

    private void xoaKhoiDonHangBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xoaKhoiDonHangBtnActionPerformed

    }//GEN-LAST:event_xoaKhoiDonHangBtnActionPerformed

    private void donViTinhFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_donViTinhFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_donViTinhFieldActionPerformed

    private void soLuongFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_soLuongFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_soLuongFieldActionPerformed

    private void tenHangFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tenHangFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tenHangFieldActionPerformed

    private void maHangFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maHangFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_maHangFieldActionPerformed

    private void hangHoaTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hangHoaTableMouseClicked
        int row = hangHoaTable.getSelectedRow();
        maHangField.setText(hangHoaTable.getValueAt(row, 0).toString());
        tenHangField.setText(hangHoaTable.getValueAt(row, 1).toString());
        donViTinhField.setText(hangHoaTable.getValueAt(row, 3).toString());
        giaBanField.setText(hangHoaTable.getValueAt(row, 4).toString());

    }//GEN-LAST:event_hangHoaTableMouseClicked

    private void themVaoDonHangBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_themVaoDonHangBtnMouseClicked

    }//GEN-LAST:event_themVaoDonHangBtnMouseClicked

    private void hoaDonTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hoaDonTableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_hoaDonTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BanHangView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BanHangView().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel banHangPanel;
    private javax.swing.JLabel dangvienLabel;
    private javax.swing.JLabel dashboardLabel;
    private com.toedter.calendar.JDateChooser dateTaoHoaDon;
    private javax.swing.JLabel doanvienLabel;
    private javax.swing.JTextField donViTinhField;
    private javax.swing.JTextField giaBanField;
    private javax.swing.JLabel hangHoaLabel;
    private javax.swing.JPanel hangHoaPanel;
    private javax.swing.JTable hangHoaTable;
    private javax.swing.JTable hoaDonTable;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPanel logoPanel;
    private javax.swing.JPanel logoutPanel1;
    private javax.swing.JButton luuHoaDonBtn;
    private javax.swing.JTextField maHangField;
    private javax.swing.JTextField maHoaDonField;
    private javax.swing.JTextField soLuongField;
    private javax.swing.JTextField tenHangField;
    private javax.swing.JTextField tenKhachHangField;
    private javax.swing.JButton themVaoDonHangBtn;
    private javax.swing.JPanel thongKeHoaDonPanel;
    private javax.swing.JPanel thongkePanel;
    private javax.swing.JLabel tongTienLable;
    private javax.swing.JButton xoaKhoiDonHangBtn;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Integer> getListMahangHoaFromHangHoaTable() {
        List<Integer> listMaHangHoa = new ArrayList<>();
        TableModel tableModel = hangHoaTable.getModel();
        int rowCount = tableModel.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            int maHangHoa = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
            listMaHangHoa.add(maHangHoa);
        }
        return listMaHangHoa;
    }

    public List<Integer> getListMahangHoaFromHoaDonTable() {
        List<Integer> listMaHangHoa = new ArrayList<>();
        TableModel tableModel = hoaDonTable.getModel();
        int rowCount = tableModel.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            int maHangHoa = Integer.parseInt(tableModel.getValueAt(i, 0).toString());
            listMaHangHoa.add(maHangHoa);
        }
        return listMaHangHoa;
    }

    public JTable getHangHoaTable() {
        return this.hangHoaTable;
    }

    public JTable getHoaDonTable() {
        return this.hoaDonTable;
    }

    public int getHangHoaFromSelectedRow() {
        return hangHoaTable.getSelectedRow();
    }

    public int getHoaDonFromSelectedRow() {
        return hoaDonTable.getSelectedRow();
    }

    public void setEnableThemVaoDonHang(boolean isEnable) {
        this.themVaoDonHangBtn.setEnabled(isEnable);
    }

    public void setEnableXoaKhoiDonHang(boolean isEnable) {
        this.xoaKhoiDonHangBtn.setEnabled(isEnable);
    }

    public void setEnableLuuHoaDon(boolean isEnable) {
        this.luuHoaDonBtn.setEnabled(isEnable);
    }

    public void addThemVaoDonHangListener(ActionListener listener) {
        themVaoDonHangBtn.addActionListener(listener);
    }

    public void addXoaKhoiDonHangListener(ActionListener listener) {
        xoaKhoiDonHangBtn.addActionListener(listener);
    }

    public void addLuuHoaDonListener(ActionListener listener) {
        luuHoaDonBtn.addActionListener(listener);
    }

    public void addListHangHoaSelectionListener(ListSelectionListener listener) {
        hangHoaTable.getSelectionModel().addListSelectionListener(listener);
    }

    public void addListHoaDonSelectionListener(ListSelectionListener listener) {
        hoaDonTable.getSelectionModel().addListSelectionListener(listener);
    }

    public void setTextMaHangField() {
        maHangField.setText("");
    }

    public void setTextTenHanfField() {
        tenHangField.setText("");
    }

    public void setTexDonViTinhField() {
        donViTinhField.setText("");
    }

    public void setTextGiaBanField() {
        giaBanField.setText("");
    }

    public void setTextSoLuongField() {
        soLuongField.setText("");
    }

    public void setTextMaHoaDonField() {
        maHoaDonField.setText("");
    }

    public void setTextTenKhacHangFieldField() {
        tenKhachHangField.setText("");
    }

    public void setDateLuuHoaDonField() {
        dateTaoHoaDon.setDate(null);
    }

    public void setTextTongTienLabel(String text) {
        tongTienLable.setText(text);
    }

    public double getTextTongTienLabel() {
        return Double.parseDouble(tongTienLable.getText());
    }

}
