/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vn.viettuts.qlsv.dao;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import vn.viettuts.qlsv.entity.HoaDon;
import vn.viettuts.qlsv.entity.HoaDonXML;
import vn.viettuts.qlsv.utils.FileUtils;

/**
 *
 * @author JC
 */
public class HoaDonDao {

    private static final String STUDENT_FILE_NAME = "/config/hoadon.xml";
    private List<HoaDon> listHoaDon;

    public HoaDonDao() {
        this.listHoaDon = readListHoaDon();
        if (listHoaDon == null) {
            listHoaDon = new ArrayList<HoaDon>();
        }
    }
    
    public void writeListHoaDon(List<HoaDon> listHangHoa) {
        HoaDonXML hangHoaXML = new HoaDonXML();
        hangHoaXML.setListHoaDon(listHangHoa);
        FileUtils.writeXMLtoFile(STUDENT_FILE_NAME, hangHoaXML);
    }
    
    public List<HoaDon> readListHoaDon() {
        List<HoaDon> list = new ArrayList<HoaDon>();
        try (InputStream inputStream = getClass().getResourceAsStream("/config/hoadon.xml")) {
            if (inputStream != null) {
                HoaDonXML studentXML = (HoaDonXML) FileUtils.readXMLFromInputStream(inputStream, HoaDonXML.class);
                if (studentXML != null) {
                    list = studentXML.getListHoaDon();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public void add(HoaDon hangHoa) {
        int maHangHoa = 1;
        if (listHoaDon != null && listHoaDon.size() > 0) {
            maHangHoa = listHoaDon.size() + 1;
        }
        hangHoa.setMaHang(maHangHoa);
        listHoaDon.add(hangHoa);
        writeListHoaDon(listHoaDon);
    }
    
    public void edit(HoaDon hangHoa) {
        int size = listHoaDon.size();
        for (int i = 0; i < size; i++) {
            if (listHoaDon.get(i).getMaHang()== hangHoa.getMaHang()) {                
                listHoaDon.get(i).setTenHangHoa(hangHoa.getTenHangHoa());
                listHoaDon.get(i).setSoLuongMua(hangHoa.getSoLuongMua());
                listHoaDon.get(i).setDonViTinh(hangHoa.getDonViTinh());
                listHoaDon.get(i).setGiaBan(hangHoa.getGiaBan());
                         
                writeListHoaDon(listHoaDon);
                break;
            }
        }
    }
    
     public void delete(HoaDon hangHoa) {
        boolean isFound = false;
        int size = listHoaDon.size();
        for (int i = 0; i < size; i++) {
            if (listHoaDon.get(i).getMaHang()== hangHoa.getMaHang()) {
                hangHoa = listHoaDon.get(i);
                isFound = true;
                break;
            }
        }
        if (isFound) {      
            for (int k=hangHoa.getMaHang(); k<size; k++){
                listHoaDon.get(k).setMaHang(k);
            }
            listHoaDon.remove(hangHoa);
            writeListHoaDon(listHoaDon);
        }
    }
     
     public void sortHoaDontByMaHangHoa() {
        Collections.sort(listHoaDon, new Comparator<HoaDon>() {
            @Override
            public int compare(HoaDon hangHoa1, HoaDon hangHoa2) {
                if (hangHoa1.getMaHang() > hangHoa1.getMaHang()) {
                    return 1;
                }
                return -1;
            }
        });
    }
     
     public List<HoaDon> getListHoaDon() {
        return listHoaDon;
    }
     
     public void setListHoaDon(List<HoaDon> listHoaDon) {
        this.listHoaDon = listHoaDon;
    }

}
